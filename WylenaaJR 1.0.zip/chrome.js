var wylenaajr_nav = {
    doNotification: function() {
        chrome.notifications.clear('notifyON' + wylenaajr_params.title, function(id) { });
        chrome.notifications.create('notifyON' + wylenaajr_params.title, { type: "basic", title: wylenaajr_params.title, message: wylenaajr_params.message, iconUrl: "wylenaajr_on_128.png" }, function(id) { });
    },
    setIconON: function(on) {
        var status = on ? "on" : "off";
        chrome.browserAction.setIcon({path : "wylenaajr_" + status + "_48.png"});
    },
    goIt: function() {
        if(wylenaajr.isON){
            chrome.tabs.create({url:wylenaajr.getCurrentRedirectUrl()},function(tab){});
        } else {
            chrome.tabs.create({url:wylenaajr_params.offlineUrl},function(tab){});
        }
    }
}

chrome.browserAction.onClicked.addListener(wylenaajr_nav.goIt);
chrome.notifications.onClicked.addListener(function(notificationId){
    if (notificationId === 'notifyON' + wylenaajr_params.title) {
        chrome.tabs.create({url:wylenaajr.getCurrentRedirectUrl()},function(tab){});
    }
});

wylenaajr_nav.setIconON(false);
var wylenaajr = new BtnLive(wylenaajr_params.chaines, function(result) {
    wylenaajr_nav.setIconON(result);
    if (result) {
        wylenaajr_nav.doNotification();
    }
}, 60000, 2);

